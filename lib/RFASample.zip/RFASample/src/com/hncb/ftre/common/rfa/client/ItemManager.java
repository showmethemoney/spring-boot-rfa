package com.hncb.ftre.common.rfa.client;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.log4j.Logger;

import com.hncb.ftre.common.QuoteStream;
import com.hncb.ftre.common.rfa.CallableReutersQuote;
import com.reuters.rfa.common.Client;
import com.reuters.rfa.common.Event;
import com.reuters.rfa.common.Handle;
import com.reuters.rfa.omm.OMMAttribInfo;
import com.reuters.rfa.omm.OMMMsg;
import com.reuters.rfa.omm.OMMPool;
import com.reuters.rfa.rdm.RDMInstrument;
import com.reuters.rfa.rdm.RDMMsgTypes;
import com.reuters.rfa.session.omm.OMMItemEvent;
import com.reuters.rfa.session.omm.OMMItemIntSpec;

public class ItemManager implements Client {
	private static final Logger log = Logger.getLogger(ItemManager.class);
	
	CallableReutersQuote _mainApp;
	
	//private ArrayList<Handle> _itemHandles;
	
	Handle _directoryHandle;
    Map<Handle, String> _pendingDictionaries;
    List<String> _loadedDictionaries;
    private HashMap<Handle, String> _handleIdentifiers = new HashMap<Handle, String>(); // Key handle : Value
    private HashMap<String, Handle> _idenHandles = new HashMap<String, Handle>(); // Key handle : Value
                                                   		// dictionaryType - rfaj1781
    public ItemManager(CallableReutersQuote mainApp) {
		_mainApp = mainApp;
		
		//_itemHandles = new ArrayList<Handle>();
	}
	
	public void sendRequest() {
        log.info("SendRequest: Sending item requests");
        
		// register for each item
        for (String itemName : QuoteStream.identifierSet) {
        	log.debug("Subscribing Identifier: " + itemName );
        	registerItem(itemName);
        }
    }
	
	public void registerItem(String itemName) {
		String serviceName = _mainApp.get_serviceName();
        
        short msgModelType = RDMMsgTypes.MARKET_PRICE;

        OMMItemIntSpec ommItemIntSpec = new OMMItemIntSpec();

        //Preparing item request message
        OMMPool pool = _mainApp.get_pool();
        OMMMsg ommmsg = pool.acquireMsg();

        ommmsg.setMsgType(OMMMsg.MsgType.REQUEST);
        ommmsg.setMsgModelType(msgModelType);
        ommmsg.setIndicationFlags(OMMMsg.Indication.REFRESH);
        ommmsg.setPriority((byte) 1, 1);
        
        // Setting OMMMsg with negotiated version info from login handle        
        if( _mainApp.get_loginClient().getHandle() != null ) {
        	ommmsg.setAssociatedMetaInfo( _mainApp.get_loginClient().getHandle() );
        }
        
		// register for each item
        ommmsg.setAttribInfo(serviceName, itemName, RDMInstrument.NameType.RIC);

    	//Set the message into interest spec
        ommItemIntSpec.setMsg(ommmsg);
        
        Handle  itemHandle = _mainApp.get_ommConsumer().registerClient(_mainApp.get_eventQueue(), ommItemIntSpec, this, null);
        
        _handleIdentifiers.put(itemHandle, itemName);
        _idenHandles.put(itemName, itemHandle);
        
        pool.releaseMsg(ommmsg);
	}
	
	public void closeRequest() {
    	for (Handle itemHandle : _handleIdentifiers.keySet()) {
            _mainApp.get_ommConsumer().unregisterClient(itemHandle);
            _idenHandles.remove(_handleIdentifiers.get(itemHandle));
            _handleIdentifiers.remove(itemHandle);
        }
    }
	
    public void removeItem(String itemName) {
    	log.info("Remove Item: " + itemName);
    	Handle itemHandle = _idenHandles.get(itemName);
    	if(itemHandle != null) {
    		_mainApp.get_ommConsumer().unregisterClient(itemHandle);
    		_idenHandles.remove(itemName);
            _handleIdentifiers.remove(itemHandle);
    	}
    }
	
	@Override
	public void processEvent(Event event) {
		// TODO Auto-generated method stub
		
		if (event.getType() == Event.COMPLETION_EVENT) {
    		//System.out.println(_className+": Receive a COMPLETION_EVENT, "+ event.getHandle());
    		return;
    	}

    	// check for an event type; it should be item event.
        //System.out.println(_className+".processEvent: Received Item Event");
        if (event.getType() != Event.OMM_ITEM_EVENT) {
            //System.out.println("ERROR: "+_className+" Received an unsupported Event type.");
            _mainApp.cleanup();
            return;
        }
        
        OMMItemEvent ie = (OMMItemEvent) event;
        OMMMsg respMsg = ie.getMsg();
        GenericOMMParser.setItemName(_handleIdentifiers.get(event.getHandle()));
		GenericOMMParser.parse(respMsg);
	}

    boolean _isComplete;
}
