package com.hncb.ftre.common.rfa.client;

import java.io.ByteArrayInputStream;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Locale;
import java.util.Vector;

import org.apache.log4j.Logger;

import com.hncb.ftre.common.QuoteStream;
import com.reuters.rfa.ansipage.Page;
import com.reuters.rfa.ansipage.PageUpdate;
import com.reuters.rfa.common.PublisherPrincipalIdentity;
import com.reuters.rfa.dictionary.DataDef;
import com.reuters.rfa.dictionary.DataDefDictionary;
import com.reuters.rfa.dictionary.DictionaryException;
import com.reuters.rfa.dictionary.ElementEntryDef;
import com.reuters.rfa.dictionary.FidDef;
import com.reuters.rfa.dictionary.FieldDictionary;
import com.reuters.rfa.dictionary.FieldEntryDef;
import com.reuters.rfa.omm.OMMAttribInfo;
import com.reuters.rfa.omm.OMMData;
import com.reuters.rfa.omm.OMMDataBuffer;
import com.reuters.rfa.omm.OMMDataDefs;
import com.reuters.rfa.omm.OMMElementEntry;
import com.reuters.rfa.omm.OMMEntry;
import com.reuters.rfa.omm.OMMEnum;
import com.reuters.rfa.omm.OMMException;
import com.reuters.rfa.omm.OMMFieldEntry;
import com.reuters.rfa.omm.OMMFieldList;
import com.reuters.rfa.omm.OMMFilterEntry;
import com.reuters.rfa.omm.OMMFilterList;
import com.reuters.rfa.omm.OMMIterable;
import com.reuters.rfa.omm.OMMMap;
import com.reuters.rfa.omm.OMMMapEntry;
import com.reuters.rfa.omm.OMMMsg;
import com.reuters.rfa.omm.OMMPriority;
import com.reuters.rfa.omm.OMMSeries;
import com.reuters.rfa.omm.OMMTypes;
import com.reuters.rfa.omm.OMMVector;
import com.reuters.rfa.omm.OMMVectorEntry;
import com.reuters.rfa.rdm.RDMInstrument;
import com.reuters.rfa.rdm.RDMMsgTypes;
import com.reuters.rfa.utility.HexDump;

/**
 * The GenericOMMParser is used to read and initialize dictionaries and parse
 * any OMM message that is passed to it using the parse() method.
 * 
 * This class is not thread safe due to the static variables. The "CURRENT"
 * variables save state between methods, so another thread cannot change the
 * values. CURRENT_DICTIONARY requires only one FieldDictionary to be used at a
 * time. CURRENT_PAGE requires only one page to be parsed at a time.
 */

@SuppressWarnings("unused")
public final class GenericOMMParser {
	private static final Logger log = Logger.getLogger(GenericOMMParser.class);
    private static HashMap<Integer, FieldDictionary> DICTIONARIES = new HashMap<Integer, FieldDictionary>();
    private static FieldDictionary CURRENT_DICTIONARY;
    private static Page CURRENT_PAGE;
    public static String itemName;

    private static boolean INTERNAL_DEBUG = false;

    /**
     * This method should be called one before parsing and data.
     * 
     * @param fieldDictionaryFilename
     * @param enumDictionaryFilename
     * @throws DictionaryException if an error has occurred
     */
    public static void initializeDictionary(String fieldDictionaryFilename, String enumDictionaryFilename) throws DictionaryException {
        FieldDictionary dictionary = FieldDictionary.create();
        try {
            FieldDictionary.readRDMFieldDictionary(dictionary, fieldDictionaryFilename);
            //System.out.println("field dictionary read from RDMFieldDictionary file");

            FieldDictionary.readEnumTypeDef(dictionary, enumDictionaryFilename);
            //System.out.println("enum dictionary read from enumtype.def file");

            initializeDictionary(dictionary);
        } catch (DictionaryException e) {
            throw new DictionaryException("ERROR: Check if files " + fieldDictionaryFilename + " and " + enumDictionaryFilename + " exist and are readable.", e);
        }
    }

    // This method can be used to initialize a downloaded dictionary
    public synchronized static void initializeDictionary(FieldDictionary dict) {
        int dictId = dict.getDictId();
        
        if (dictId == 0) {
        	dictId = 1; // dictId == 0 is the same as dictId 1
        }
            
        DICTIONARIES.put(new Integer(dictId), dict);
    }

    public static FieldDictionary getDictionary(int dictId) {
        
    	if (dictId == 0) {
        	dictId = 1;
        }
            
        return (FieldDictionary)DICTIONARIES.get(new Integer(dictId));
    }

    /**
     * parse msg and print it in a table-nested format to System.out
     */
    public static final void parse(OMMMsg msg) {
        parseMsg(msg);
    }

	private static final String hintString(OMMMsg msg) {
        StringBuilder buf = new StringBuilder(60);

        boolean bAppend = true;

        if (msg.has(OMMMsg.HAS_ATTRIB_INFO)) {
            bAppend = append(buf, "HAS_ATTRIB_INFO", bAppend);
        }
        if (msg.has(OMMMsg.HAS_CONFLATION_INFO)) {
            bAppend = append(buf, "HAS_CONFLATION_INFO", bAppend);
        }
        if (msg.has(OMMMsg.HAS_HEADER)) {
            bAppend = append(buf, "HAS_HEADER", bAppend);
        }
        if (msg.has(OMMMsg.HAS_ITEM_GROUP)) {
            bAppend = append(buf, "HAS_ITEM_GROUP", bAppend);
        }
        if (msg.has(OMMMsg.HAS_PERMISSION_DATA)) {
        	//System.out.println(itemName + " HAS_PERMISSION_DATA");
            bAppend = append(buf, "HAS_PERMISSION_DATA", bAppend);
        }
        if (msg.has(OMMMsg.HAS_PRIORITY)) {
            bAppend = append(buf, "HAS_PRIORITY", bAppend);
        }
        if (msg.has(OMMMsg.HAS_QOS)) {
            bAppend = append(buf, "HAS_QOS", bAppend);
        }
        if (msg.has(OMMMsg.HAS_QOS_REQ)) {
            bAppend = append(buf, "HAS_QOS_REQ", bAppend);
        }
        if (msg.has(OMMMsg.HAS_RESP_TYPE_NUM)) {
            bAppend = append(buf, "HAS_RESP_TYPE_NUM", bAppend);
        }
        if (msg.has(OMMMsg.HAS_SEQ_NUM)) {
            bAppend = append(buf, "HAS_SEQ_NUM", bAppend);
        }
        if (msg.has(OMMMsg.HAS_ID)) {
            bAppend = append(buf, "HAS_ID", bAppend);
        }
        if (msg.has(OMMMsg.HAS_PUBLISHER_INFO)) {
            bAppend = append(buf, "HAS_PUBLISHER_INFO", bAppend);
        }
        if (msg.has(OMMMsg.HAS_STATE)) {
            bAppend = append(buf, "HAS_STATE", bAppend);
        }
        if (msg.has(OMMMsg.HAS_USER_RIGHTS)) {
            bAppend = append(buf, "HAS_USER_RIGHTS", bAppend);
        }

        return buf.toString();
    }

    private static boolean append(StringBuilder buf, String str, boolean first) {
        if (!first) {
            buf.append(" | ");
            first = false;
        } else {
        	first = false;
        }
            
        buf.append(str);
        return first;
    }
    
    /**
     * parse msg and print it in a table-nested format to the provided
     * PrintStream
     */
    public static final void parseMsg(OMMMsg msg) {
        msg.getMsgType();
        
        //System.out.println("DataType:" + msg.getDataType());
        
        if(msg.getDataType() == OMMTypes.PERMISSION_DATA) {
        	log.warn(itemName + " is PERMISSION_DATA"); 
        }

        if ((msg.getDataType() == OMMTypes.ANSI_PAGE) && msg.isSet(OMMMsg.Indication.CLEAR_CACHE)) {
            CURRENT_PAGE = null;
        }

        if (msg.has(OMMMsg.HAS_STATE)) {
            // 
            //System.out.println("State: " + msg.getState());
        }
        
        if (msg.has(OMMMsg.HAS_PRIORITY)) {
            // 
            OMMPriority p = msg.getPriority();
            if (p != null){
                //System.out.println("Priority: " + p.getPriorityClass() + "," + p.getCount());
            } else{
            //System.out.println("Priority: Error flag recieved but there is not priority present");
            }
        }
        
        if (msg.has(OMMMsg.HAS_QOS)) {
            // 
            //System.out.println("Qos: " + msg.getQos());
        }
        
        if (msg.has(OMMMsg.HAS_QOS_REQ)) {
            // 
            //System.out.println("QosReq: " + msg.getQosReq());
        }
        
        if (msg.has(OMMMsg.HAS_ITEM_GROUP)) {
            // 
            //System.out.println("Group: " + msg.getItemGroup());
        }
        
        if (msg.has(OMMMsg.HAS_PERMISSION_DATA)) {
        	byte[] permdata = msg.getPermissionData();
        	
            // 
        	//System.out.println(itemName + " PermissionData: " + HexDump.toHexString(permdata, false));
        	//System.out.println(itemName + " ( " + HexDump.formatHexString(permdata) + " ) ");
        }
        
        if (msg.has(OMMMsg.HAS_SEQ_NUM)) {
            // 
            //System.out.println("SeqNum: " + msg.getSeqNum());
        }

        if (msg.has(OMMMsg.HAS_CONFLATION_INFO)) {
            // 
           // //System.out.println("Conflation Count: " + msg.getConflationCount());
            // 
            //System.out.println("Conflation Time: " + msg.getConflationTime());
        }

        if (msg.has(OMMMsg.HAS_RESP_TYPE_NUM)) {
            // 
            //ps.print("RespTypeNum: " + msg.getRespTypeNum());
            dumpRespTypeNum(msg);
        }

        if (msg.has(OMMMsg.HAS_ID)) {
           //  
            //System.out.println("Id: " + msg.getId());
        }

        if ((msg.has(OMMMsg.HAS_PUBLISHER_INFO)) || (msg.getMsgType() == OMMMsg.MsgType.POST)) {
            PublisherPrincipalIdentity pi = (PublisherPrincipalIdentity)msg.getPrincipalIdentity();
            if (pi != null) {
               //  
                //System.out.println("Publisher Address: 0x" + Long.toHexString(pi.getPublisherAddress()));
               //  
                //System.out.println("Publisher Id: " + pi.getPublisherId());
            }
        }

        if (msg.has(OMMMsg.HAS_USER_RIGHTS) ) {
        	// 
        	//System.out.println("User Rights Mask: " + OMMMsg.UserRights.userRightsString(msg.getUserRightsMask()));
        }

        if (msg.has(OMMMsg.HAS_ATTRIB_INFO)) {
           //  
            //System.out.println("AttribInfo");
            OMMAttribInfo ai = msg.getAttribInfo();
            if (ai.has(OMMAttribInfo.HAS_SERVICE_NAME)) {
              //   
                //System.out.println("ServiceName: " + ai.getServiceName());
            }
            
            if (ai.has(OMMAttribInfo.HAS_SERVICE_ID)) {
           //      
                //System.out.println("ServiceId: " + ai.getServiceID());
            }
            
            if (ai.has(OMMAttribInfo.HAS_NAME)) {
          //       
               // //System.out.println("Name: " + ai.getName());
            }
            
            if (ai.has(OMMAttribInfo.HAS_NAME_TYPE)) {
               //  
                //ps.print("NameType: " + ai.getNameType());
                if (msg.getMsgModelType() == RDMMsgTypes.LOGIN) {
                    //System.out.println(" (" + RDMUser.NameType.toString(ai.getNameType()) + ")");
                } else if (RDMInstrument.isInstrumentMsgModelType(msg.getMsgModelType())) {

                    //System.out.println(" (" + RDMInstrument.NameType.toString(ai.getNameType()) + ")");
                } else {
                    //System.out.println();
                }
            }
            if (ai.has(OMMAttribInfo.HAS_FILTER)) {
              //   
                //ps.print("Filter: " + ai.getFilter());
                if (msg.getMsgModelType() == RDMMsgTypes.DIRECTORY) {
                    //System.out.println(" (" + RDMService.Filter.toString(ai.getFilter()) + ")");
                } else if (msg.getMsgModelType() == RDMMsgTypes.DICTIONARY) {
                    //System.out.println(" (" + RDMDictionary.Filter.toString(ai.getFilter()) + ")");
                } else {
                    //System.out.println();
                }
            }
            if (ai.has(OMMAttribInfo.HAS_ID)) {
              //   
                //System.out.println("ID: " + ai.getId());
            }
            if (ai.has(OMMAttribInfo.HAS_ATTRIB)) {
             //    
                //System.out.println("Attrib");
                parseData(ai.getAttrib());
            }
        }
        
        
        
        //System.out.println(OMMTypes.NO_DATA);
       //  
        //ps.print("Payload: ");
        if (msg.getDataType() != OMMTypes.NO_DATA) {
            //System.out.println(msg.getPayload().getEncodedLength() + " bytes");
            parseData(msg.getPayload());
        } else {
            //System.out.println(itemName + " None.");
        }
    }

    /**
     * parse msg and print it in a table-nested format to the provided
     * PrintStream
     */
    @SuppressWarnings("rawtypes")
	public static final void parseDataDefinition(OMMDataDefs datadefs, short dbtype) {
        DataDefDictionary listDefDb = DataDefDictionary.create(dbtype);
        DataDefDictionary.decodeOMMDataDefs(listDefDb, datadefs);

        //ps.print("DATA_DEFINITIONS ");
        for (Iterator listDefDbIter = listDefDb.iterator(); listDefDbIter.hasNext();) {
            DataDef listdef = (DataDef)listDefDbIter.next();

            //ps.print("Count: ");
            //ps.print(listdef.getCount());
           // ps.print(" DefId: ");
           //System.out.println(listdef.getDataDefId());

            if (dbtype == OMMTypes.ELEMENT_LIST_DEF_DB)
            {
                for (Iterator listdefIter = listdef.iterator(); listdefIter.hasNext();)
                {
                    ElementEntryDef ommEntry = (ElementEntryDef)listdefIter.next();
                     
                    //ps.print("ELEMENT_ENTRY_DEF ");
                   // ps.print("Name: ");
                    //ps.print(ommEntry.getName());
                   // ps.print(" Type: ");
                   // //System.out.println(OMMTypes.toString(ommEntry.getDataType()));
                }
            }
            else
            {
                for (Iterator listdefIter = listdef.iterator(); listdefIter.hasNext();)
                {
                    FieldEntryDef ommEntry = (FieldEntryDef)listdefIter.next();
                     
                   // ps.print("FIELD_ENTRY_DEF ");
                    //ps.print("FID: ");
                   // ps.print(ommEntry.getFieldId());
                   // ps.print(" Type: ");
                   // //System.out.println(OMMTypes.toString(ommEntry.getDataType()));
                }
            }
        }
    }

    private static void dumpRespTypeNum(OMMMsg msg) {
        if (msg.getMsgType() == OMMMsg.MsgType.REFRESH_RESP) {
            //System.out.println(" (" + OMMMsg.RespType.toString(msg.getRespTypeNum()) + ")");
        } else { // msg.getMsgType() == OMMMsg.OMMMsg.MsgType.UPDATE_RESP
            if ((msg.getMsgModelType() >= RDMMsgTypes.MARKET_PRICE) && (msg.getMsgModelType() <= RDMMsgTypes.HISTORY)) {
                //System.out.println(" (" + RDMInstrument.Update.toString(msg.getRespTypeNum()) + ")");
            }
        }
    }

    /**
     * parse data and print it in a table-nested format to the System.out
     */

	public static final void parse(OMMData data) {
        parseData(data);
    }
    
    @SuppressWarnings("rawtypes")
	private static final void parseAggregate(OMMData data) {
    
        parseAggregateHeader(data);
        
        for (Iterator iter = ((OMMIterable)data).iterator(); iter.hasNext();) {
            OMMEntry entry = (OMMEntry)iter.next();
            parseEntry(entry);
        }
    }

    /**
     * parse data and print it in a table-nested format to the provided
     * PrintStream
     */
    @SuppressWarnings("rawtypes")
	public static final void parseData(OMMData data) {
    	//System.out.println("OMMDataType:" + data.getType());
    	
    	//System.out.println("OMMTypes.isAggregate(data.getType()) ---> " + OMMTypes.isAggregate(data.getType()));
    	
        if (data.isBlank()) { 
        	 
        } else if (OMMTypes.isAggregate(data.getType())) {
        	parseAggregate(data);
        } else if ((data.getType() == OMMTypes.RMTES_STRING) && ((OMMDataBuffer)data).hasPartialUpdates()) {
            Iterator iter = ((OMMDataBuffer)data).partialUpdateIterator();
            while (true) {
                OMMDataBuffer partial = (OMMDataBuffer)iter.next();
                //ps.print("hpos: ");
                //ps.print(partial.horizontalPosition());
                //ps.print(", ");
                //ps.print(partial.toString());
                if (iter.hasNext()){
                    //ps.print("  |  ");
                } else {
                	break;
                }   
            }
            //System.out.println();
        } else if (data.getType() == OMMTypes.ANSI_PAGE) {
            // process ANSI with com.reuters.rfa.ansipage
            parseAnsiPageData(data);
        } else if (data.getType() == OMMTypes.BUFFER || data.getType() == OMMTypes.OPAQUE_BUFFER) {
            if (data.getEncodedLength() <= 20) {
                 
                // for small strings, print hex and try to print ASCII
                //ps.print(HexDump.toHexString(((OMMDataBuffer)data).getBytes(), false));
               //ps.print(" | ");
                //System.out.println(data);
            } else {
                if (INTERNAL_DEBUG) {
                   // //System.out.println("Hex Format and Data Bytes: ");
                   // //System.out.println(HexDump.hexDump(((OMMDataBuffer)data).getBytes(), 50));

                   // //System.out.println("Hex Format: ");
                }

                int lineSize = 32;
                String s = HexDump.toHexString(((OMMDataBuffer)data).getBytes(), false);

                int j = 0;
                while (j < s.length()) {
                    if (j != 0){
                       // //System.out.println();
                    }
                    

                    int end = j + lineSize;
                    
                    if (end >= s.length()) end = s.length();

                    for (int i = j; i < end; i++) {
                       // ps.print(s.charAt(i));
                    }
                    
                    j = j + lineSize;
                }

               // //System.out.println("\nData Bytes: ");
                
               // //System.out.println(data);
            }
        }
        else if (data.getType() == OMMTypes.MSG) {
            parseMsg((OMMMsg)data);
        } else {
            try {
               // //System.out.println(data);
            } catch (Exception e) {
                byte[] rawdata = data.getBytes();
                //System.out.println(HexDump.hexDump(rawdata));
            }
        }
    }

    private static final void parseAggregateHeader(OMMData data) {
         
        short dataType = data.getType();
        //System.out.println(OMMTypes.toString(dataType));
        switch (dataType) {
            case OMMTypes.FIELD_LIST: {
                // set DICTIONARY to the dictId for this field list
                OMMFieldList fieldList = (OMMFieldList)data;
                int dictId = fieldList.getDictId();
                CURRENT_DICTIONARY = getDictionary(dictId);
            }
                break;
            case OMMTypes.SERIES:
            {
                OMMSeries s = (OMMSeries)data;
                if (s.has(OMMSeries.HAS_SUMMARY_DATA))
                {
                     
                    //System.out.println("SUMMARY");
                    parseData(s.getSummaryData());
                }
                if (s.has(OMMSeries.HAS_DATA_DEFINITIONS))
                {
                     
                    short dbtype = s.getDataType() == OMMTypes.FIELD_LIST ? OMMTypes.FIELD_LIST_DEF_DB : OMMTypes.ELEMENT_LIST_DEF_DB;
                    parseDataDefinition(s.getDataDefs(), dbtype);
                }
            }
                break;
            case OMMTypes.MAP:
            {
                OMMMap s = (OMMMap)data;

                String flagsString = DataUtil.mapFlagsString(s);
                 
              //  ps.print("flags: ");
               // //System.out.println(flagsString);

                if (s.has(OMMMap.HAS_SUMMARY_DATA))
                {
                     
                    //System.out.println("SUMMARY");
                    parseData(s.getSummaryData());
                }
            }
                break;
            case OMMTypes.VECTOR:
            {
                OMMVector s = (OMMVector)data;

                String flagsString = DataUtil.vectorFlagsString(s);
                 
               // ps.print("flags: ");
                //System.out.println(flagsString);

                if (s.has(OMMVector.HAS_SUMMARY_DATA))
                {
                     
                   // //System.out.println("SUMMARY");
                    parseData(s.getSummaryData());
                }
            }
                break;
            case OMMTypes.FILTER_LIST:
            {
                OMMFilterList s = (OMMFilterList)data;

                String flagsString = DataUtil.filterListFlagsString(s);
                 
                //ps.print("flags: ");
               // //System.out.println(flagsString);
            }
                break;
        }
    }

    private static final void parseEntry(OMMEntry entry) {
    	
    	//System.out.println("entry: " + entry.getType());
    	
    	try {
            switch(entry.getType()) {
                case OMMTypes.FIELD_ENTRY: 
                    OMMFieldEntry fe = (OMMFieldEntry) entry;
                    if (CURRENT_DICTIONARY != null) {
                        FidDef fiddef = CURRENT_DICTIONARY.getFidDef(fe.getFieldId());
                        if (fiddef != null) {
                            dumpFieldEntryHeader(fe, fiddef);
                            OMMData data = null;
                            if (fe.getDataType() == OMMTypes.UNKNOWN) {
                            	data = fe.getData(fiddef.getOMMType());
                            } else {
                            	// defined data already has type
                                data = fe.getData();
                            }
                                
                            if (data.getType() == OMMTypes.ENUM) {
                            	for(String field : QuoteStream.fieldSet) {
                                	if(field.equals(fiddef.getName())) {
                                		String val = CURRENT_DICTIONARY.expandedValueFor(fiddef.getFieldId(), ((OMMEnum)data).getValue());
                                		System.out.println("ENUM : " + itemName + ", " + fiddef.getName() + " = " + val);
                                		QuoteStream.quoteMap.put(itemName+","+field, val);
                                	}
                                }
                            } else {
                            	if("VALUE_DT1".equals(fiddef.getName())) {
                                	Locale locale = Locale.US;
                                	SimpleDateFormat df = new SimpleDateFormat("dd MMM yyyy", locale);
                                	String dateString = null;
                                	try {
    									Date date = df.parse(data.toString());
    									SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
    									dateString = sdf.format(date);
    									QuoteStream.quoteMap.put(itemName+",DATE", dateString);
    								} catch (ParseException e) {
    									// TODO Auto-generated catch block
    									//e.printStackTrace();
    								}
                                } else if("VALUE_TS1".equals(fiddef.getName())) {
                                	try {
                                		QuoteStream.quoteMap.put(itemName+",TIME", data.toString());
                                	} catch(Exception e) {
                                		
                                	}
                                	
                                } else {
                                	for(String field : QuoteStream.fieldSet) {
                                    	if(field.equals(fiddef.getName())) {
                                    		System.out.println("Identifier : " + itemName + ", " + fiddef.getName() + " = " + data.toString());
                                    		QuoteStream.quoteMap.put(itemName+","+field, data.toString());
                                    	}
                                    }
                                }
                            }
                            
                            //if(itemName.equals("AUD1MD=")) System.out.println("Identifier : " + itemName + ", " + fiddef.getName() + " = " + data.toString());
                            
                            
                            
                                         	
                            
                        } else {
                            //System.out.println("Received field id: " + fe.getFieldId() + " - Not defined in dictionary");
                        }
                    } else {
                        dumpFieldEntryHeader(fe, null);
                        
                        if (fe.getDataType() == OMMTypes.UNKNOWN) {
                            OMMDataBuffer data = (OMMDataBuffer)fe.getData();
                            //System.out.println(HexDump.toHexString(data.getBytes(), false));
                        } else {      // defined data already has type
                            OMMData data = fe.getData();
                            parseData(data);
                        }
                    }
                    break;
                case OMMTypes.ELEMENT_ENTRY:
                    dumpElementEntryHeader((OMMElementEntry)entry);
                    
                    parseData(entry.getData());
                    
                    break;
                case OMMTypes.MAP_ENTRY:
                    dumpMapEntryHeader((OMMMapEntry)entry);
                    
                    if ((((OMMMapEntry)entry).getAction() != OMMMapEntry.Action.DELETE) && entry.getDataType() != OMMTypes.NO_DATA) {
                    	parseData(entry.getData());
                    }
                        
                    break;
                case OMMTypes.VECTOR_ENTRY:
                    dumpVectorEntryHeader((OMMVectorEntry)entry);
                    
                    if ((((OMMVectorEntry)entry).getAction() != OMMVectorEntry.Action.DELETE) && (((OMMVectorEntry)entry).getAction() != OMMVectorEntry.Action.CLEAR)) {
                    	parseData(entry.getData());
                    }
                        
                    break;
                case OMMTypes.FILTER_ENTRY:
                    dumpFilterEntryHeader((OMMFilterEntry)entry);
                    
                    if (((OMMFilterEntry)entry).getAction() != OMMFilterEntry.Action.CLEAR) {
                    	parseData(entry.getData());
                    }
                    
                    break;                    
                default:
                    dumpEntryHeader(entry);
                    
                    parseData(entry.getData());
                    
                    break;
            }
        } catch (OMMException e) {
            
        }
    }

    private static final void dumpEntryHeader(OMMEntry entry) {
        if (entry.getType() == OMMTypes.SERIES_ENTRY){
            //System.out.println("SERIES_ENTRY");
        }
    }

    private static final void dumpFieldEntryHeader(OMMFieldEntry entry, FidDef def) {
         
        //ps.print(OMMTypes.toString(entry.getType()));
        //ps.print(" ");
        //ps.print(entry.getFieldId());
        if (def == null) {
            //ps.print(": ");
        } else {
            //ps.print("/");
            //ps.print(def.getName());
            //ps.print(": ");
            if ((def.getOMMType() >= OMMTypes.BASE_FORMAT) || (def.getOMMType() == OMMTypes.ARRAY)){
                //System.out.println();
            }
        }
    }

    private static final void dumpElementEntryHeader(OMMElementEntry entry) { 
        // ps.print(OMMTypes.toString(entry.getType()));
        // ps.print(" ");
        // ps.print(entry.getName());
        // ps.print(": ");
        if ((entry.getDataType() >= OMMTypes.BASE_FORMAT) || (entry.getDataType() == OMMTypes.ARRAY)){
           // //System.out.println();
        }
    }

    private static final void dumpFilterEntryHeader(OMMFilterEntry entry) {
         
        //ps.print(OMMTypes.toString(entry.getType()));
        //ps.print(" ");
        //ps.print(entry.getFilterId());
        // ps.print(" (");
        // ps.print(OMMFilterEntry.Action.toString(entry.getAction()));
        if (entry.has(OMMFilterEntry.HAS_PERMISSION_DATA)){
            //ps.print(", HasPermissionData");
        }
        if (entry.has(OMMFilterEntry.HAS_DATA_FORMAT)){
            //ps.print(", HasDataFormat");
        }
        // //System.out.println(") : ");

        String flagsString = DataUtil.filterEntryFlagsString(entry);
         
        //ps.print("flags: ");
        //System.out.println(flagsString);
    }

    private static final void dumpMapEntryHeader(OMMMapEntry entry) { 
        // ps.print(OMMTypes.toString(entry.getType()));
        // ps.print(" (");
        // ps.print(OMMMapEntry.Action.toString(entry.getAction()));
        if (entry.has(OMMMapEntry.HAS_PERMISSION_DATA)){
            //ps.print(", HasPermissionData");
        }
        //System.out.println(") : ");

        String flagsString = DataUtil.mapEntryFlagsString(entry);
         
        //ps.print("flags: ");
        //System.out.println(flagsString);

         
        //ps.print("Key: ");
        parseData(entry.getKey());
         
        // //System.out.println("Value: ");
    }

    private static final void dumpVectorEntryHeader(OMMVectorEntry entry) {
         
        //ps.print(OMMTypes.toString(entry.getType()));
        //ps.print(" ");
       // ps.print(entry.getPosition());
       // ps.print(" (");
       // ps.print(OMMVectorEntry.Action.vectorActionString(entry.getAction()));
        if (entry.has(OMMVectorEntry.HAS_PERMISSION_DATA)){
            //ps.print(", HasPermissionData");
        }
        //System.out.println(") : ");

        String flagsString = DataUtil.vectorEntryFlagsString(entry);
         
        //ps.print("flags: ");
       //System.out.println(flagsString);

    }

    public static final void parseAnsiPageData(OMMData data) {
        boolean newPage = false;
        if (CURRENT_PAGE == null) {
            CURRENT_PAGE = new Page();
            newPage = true;
        }

        Vector<PageUpdate> pageUpdates = new Vector<PageUpdate>();
        ByteArrayInputStream bais = new ByteArrayInputStream(data.getBytes());
        CURRENT_PAGE.decode(bais, pageUpdates);
        if (newPage){
            //System.out.println(CURRENT_PAGE.toString()); // print the page if it is a refresh message
        } else {
            // print the update string
            Iterator<PageUpdate> iter = pageUpdates.iterator();
            while (iter.hasNext()) {
                PageUpdate u = (PageUpdate)iter.next();
                StringBuilder buf = new StringBuilder(80);
                for (short k = u.getBeginningColumn(); k < u.getEndingColumn(); k++) {
                    buf.append(CURRENT_PAGE.getChar(u.getRow(), k));
                }
                if (!(buf.toString()).equalsIgnoreCase("")) {
                     
                    //System.out.println("Update String: " + buf.toString() + " (Row: " + u.getRow()  + ", Begin Col: " + u.getBeginningColumn() + ", End Col: "     + u.getEndingColumn() + ")");
                }
            }
        }
    }

	public static String getItemName() {
		return itemName;
	}

	public static void setItemName(String itemName) {
		GenericOMMParser.itemName = itemName;
	}
	
	public static Long getDateTimeInMillis(Date date){
		Calendar gCal = new GregorianCalendar();
        gCal.setTime(date);
        return gCal.getTimeInMillis();
	}
	
	public static FieldDictionary getFieldDictionary() {
		return CURRENT_DICTIONARY;
	}

}
