package com.hncb.ftre.common;

import java.util.HashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;

public class QuoteStream {
	public static Map<String, String> quoteMap = new HashMap<String, String>();
	//public static Map<Integer, MDIMap> feedMap = new HashMap<Integer, MDIMap>();
	// Subscribing identifier & filter field
	public static Set<String> identifierSet = new LinkedHashSet<String>();
	public static Set<String> fieldSet = new LinkedHashSet<String>();
	
	public static boolean addItem = false;
	public static Boolean cancel = false;
	public static Boolean loginSuccess = false;
	
	/*public static void setMDIMap(MDIMap mdiMap) {
		String identifier = mdiMap.getIdentifier();
		identifierSet.add(identifier);
		
		fieldSet.addAll(mdiMap.findAllFields());
		
		feedMap.put(mdiMap.getMdiMapId(), mdiMap);
	}*/
	
	
	public static void clearAll() {
		identifierSet.clear();
		fieldSet.clear();
		//addItemSet.clear();
		//removeItemSet.clear();
		quoteMap.clear();
		//feedMap.clear();
	}
}
