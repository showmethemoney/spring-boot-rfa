package com.hncb.ftre.common.rfa.client;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.reuters.rfa.omm.OMMMsg;

public class PageDisplay {
	final static String[] patterns = {"?=P" , "?>P" , "??P" , "?@P" , "?AP" ,  "?BP" , "?CP" , "?DP" , "?EP" , "?FP" , "?GP" , "?HP" , "?IP" , "?JP" , "?KP" , "?LP" , "?MP" , "?NP" , "?OP" , "?PP" , "?QP" , "?RP" , "?SP"};
	final static String[] rows = {"=" , ">" , "?" , "@" , "A" ,  "B" , "C" , "D" , "E" , "F" , "G" , "H" , "I" , "J" , "K" , "L" , "M" , "N" , "O" , "P" , "Q" , "R" , "S"};
	
	public static Map<String, Map<String, String>> pageMap = new HashMap<String, Map<String, String>>();

	public static Map<String, Boolean> pageUpdater = new HashMap<String, Boolean>();
	
	public static void displayByPageName(String symbol) {
		
		Map<String, String> dataMap = pageMap.get(symbol);
		
		if(dataMap != null) {
			
		}
	}
	
	// Decode the page data received and get the list of PageUpdates.
    // Apply each PageUpdate to the display panel.
    public static void parsePageData(OMMMsg respMsg, boolean update, String symbol) {
        //Timestamp time = TimeUtil.getTimeStamp(new Date());
    	
    	Boolean _updater = pageUpdater.get(symbol);
    	    	
    	if(_updater == null) {
    		_updater = false;
    	} else if(_updater.equals(update)) {
    		_updater = update;
    	}

		pageUpdater.put(symbol, _updater);
		
		byte[] data = respMsg.getPayload().getBytes();
		
		if(!_updater){
    		List<Byte> byteList = new ArrayList<Byte>();
    		int trig = 0;
    		for(int i=0 ; i<data.length ; i++){
    			String str = new String(data, StandardCharsets.UTF_8);
    			System.out.println(str);
    			if(data[i] == 1){
    				if(i < data.length){
    					if(data[i+1] == 61){
    						trig = 1;
    					}
    				}
    				
    			}
    			if(trig == 1){
    				byteList.add(data[i]);
    			}
    		}
    		
    		for(int i=0 ; i<byteList.size() ; i++){
    			if(byteList.get(i) == 1){
    				byteList.set(i, (byte) 63);
    			}
    		}
    		
    		byte[] byteData = new byte[byteList.size()];
    		for(int i=0 ; i<byteData.length ; i++){
    			byteData[i] = byteList.get(i);
    		}
    		
    		String dataString = new String(byteData);
    		
    		if(dataString != null && !dataString.isEmpty()) {
    			for(int i=0 ; i< patterns.length ; i++){
        			if(i != patterns.length-1){
        				int rowNum = i+1;
        				try {
        					int start = dataString.indexOf(patterns[i])+3;
        					int end = dataString.indexOf(patterns[i+1]);
        					
        					String newData = dataString.substring(start, end);
        					
            				System.out.println("Row: " + rowNum + "\t\t" + newData);
        				} catch(Exception e) {
        					//e.printStackTrace();
        				}
        			}
        			
        		}
        		
            	_updater = true;
    		}
    		
    		
        } else {
        	System.out.println(symbol + " UPDATE PAGE");
        	/*List<Byte> updateList = new ArrayList<Byte>();

    		for(int i=0 ; i<data.length ; i++){
    			if(data[i] > 31){
    				updateList.add(data[i]);
    			}
    		}
    		
    		byte[] byteUpdate = new byte[updateList.size()];
    		for(int i=0 ; i<byteUpdate.length ; i++){
    			byteUpdate[i] = updateList.get(i);
    		}
    		
    		String updateString = new String(byteUpdate);
    		updateString = updateString + "S";
    		int index = updateString.indexOf("=");
    		updateString = updateString.replace(updateString.substring(0 , index), "");
    		
    		for(int i=0 ; i<rows.length ; i++){
    			if(i != rows.length-1){
    				if(updateString.contains(rows[i]) && updateString.contains(rows[i+1])){
    					String newRow = updateString.substring(updateString.indexOf(rows[i])+1, updateString.indexOf(rows[i+1]));
    					int rowNum = i+1;
    					String column = "";
    					String value = "";
    					newRow = newRow.replace("[", ",");
    					String toBeUpdated = toBeUpdatedList.get(i);
    					
    					String[] updates = newRow.split(",");
    					for(int j=1 ; j<updates.length ; j++){
    						column = updates[j].split("`")[0];
    						value = updates[j].split("`")[1];
    						char[] valueChar = value.toCharArray();
    						System.out.println("row : "+rowNum+" column : "+column+" value : "+value);
    						if(valueChar.length == 1){
    							StringBuilder myString = new StringBuilder(toBeUpdated);
    							myString.setCharAt(Integer.valueOf(column), valueChar[0]);
    							toBeUpdated = myString.toString();
        						//System.out.println(toBeUpdated);
    						} else {
    							StringBuilder myString = new StringBuilder(toBeUpdated);
    							for(int k=0 ; k<valueChar.length ; k++){
    								myString.setCharAt(Integer.valueOf(column)+k, valueChar[k]);
    							}
    							toBeUpdated = myString.toString();
        						//System.out.println(toBeUpdated);
    						}
    					}
    					toBeUpdatedList.set(i, toBeUpdated);
    				}
    			}
    			
    		}
    		
    		for(int i=0 ; i<toBeUpdatedList.size() ; i++){
    			PageUpdate pageUpd = new PageUpdate();
    			int rowNum = i+1;
    			String value = toBeUpdatedList.get(i);
    			pageUpd.setRow(rowNum);
    			pageUpd.setValue(value);
    			pageUpd.setInsertDate(time);
    			pageUpdateDao.save(pageUpd);
    		}*/

        }	
    }

}
