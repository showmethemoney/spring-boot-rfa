package com.hncb.ftre.common.rfa.client;

import java.net.InetAddress;

import org.apache.log4j.Logger;

import com.hncb.ftre.common.QuoteStream;
import com.hncb.ftre.common.rfa.CallableReutersQuote;
import com.reuters.rfa.common.Client;
import com.reuters.rfa.common.Event;
import com.reuters.rfa.common.Handle;
import com.reuters.rfa.omm.OMMElementList;
import com.reuters.rfa.omm.OMMEncoder;
import com.reuters.rfa.omm.OMMMsg;
import com.reuters.rfa.omm.OMMState;
import com.reuters.rfa.omm.OMMTypes;
import com.reuters.rfa.rdm.RDMMsgTypes;
import com.reuters.rfa.rdm.RDMUser;
import com.reuters.rfa.session.omm.OMMItemEvent;
import com.reuters.rfa.session.omm.OMMItemIntSpec;

public class LoginClient implements Client {
	// init log4j
	private static final Logger log = Logger.getLogger(LoginClient.class);
	
	private Handle _loginHandle;
	private LoginInfo _loginInfo;
	
	private String _application = "256";
    private String _position = "1.1.1.1/net";
	
	private boolean _requestPARSupport = true;
	
	CallableReutersQuote _mainApp;
	
	private static final String LOG_CATEGORY = "LoginClient";
	
	public LoginClient(CallableReutersQuote mainApp) {
		_mainApp = mainApp;
	}
	
	public void closeRequest() {
		
    	if (_loginHandle != null) {
    		
    		_mainApp.get_ommConsumer().unregisterClient(_loginHandle);
	        _loginHandle = null;
    	}
    }
	
	public void sendRequest() {

		OMMItemIntSpec spec = new OMMItemIntSpec();
        
		spec.setMsg(encodeLogin( _mainApp.get_userName() , RDMUser.NameType.USER_NAME, OMMMsg.Indication.REFRESH ));
        
		_loginHandle = _mainApp.get_ommConsumer().registerClient(_mainApp.get_eventQueue(), spec, this, null);
        
		if(_loginInfo == null) _loginInfo = new LoginInfo();
		
		_loginInfo.setHandle(_loginHandle);
    }
	
	private OMMMsg encodeLogin(String userName, short nameType, int indication) {
		
		try { 
			_position = InetAddress.getLocalHost().getHostAddress() + "/" + InetAddress.getLocalHost().getHostName(); 
		} catch( Exception e ) {
			log.debug("init position failed, ", e);
		}

        OMMEncoder encoder = _mainApp.get_pool().acquireEncoder();
        
        encoder.initialize(OMMTypes.MSG, 1000);
        
        OMMMsg msg = _mainApp.get_pool().acquireMsg();
        
        msg.setMsgType(OMMMsg.MsgType.REQUEST);
        msg.setMsgModelType(RDMMsgTypes.LOGIN);
        msg.setAttribInfo(null, userName, nameType);
        
        if (indication != 0)
            msg.setIndicationFlags(indication);

        encoder.encodeMsgInit(msg, OMMTypes.ELEMENT_LIST, OMMTypes.NO_DATA);
        
        encoder.encodeElementListInit(OMMElementList.HAS_STANDARD_DATA, (short)0, (short)0);
        
        encoder.encodeElementEntryInit(RDMUser.Attrib.ApplicationId, OMMTypes.ASCII_STRING);
        
        encoder.encodeString( _application, OMMTypes.ASCII_STRING);
        
        encoder.encodeElementEntryInit(RDMUser.Attrib.Position, OMMTypes.ASCII_STRING);
        
        encoder.encodeString( _position, OMMTypes.ASCII_STRING);
        
        encoder.encodeElementEntryInit(RDMUser.Attrib.Role, OMMTypes.UINT);
        
        encoder.encodeUInt(RDMUser.Role.CONSUMER);
        
        if ( _requestPARSupport ) {
        	
            encoder.encodeElementEntryInit(RDMUser.Attrib.SupportPauseResume, OMMTypes.UINT);
            encoder.encodeUInt(1);
        
        }
        
        encoder.encodeAggregateComplete();

        return (OMMMsg) encoder.getEncodedObject();
    }

	@Override
	public void processEvent(Event event) {
		// TODO Auto-generated method stub
		if (event.getType() == Event.COMPLETION_EVENT) {
			log.info("Receive a COMPLETION_EVENT, "+ event.getHandle());
    		return;
    	}

		log.info("processEvent: Received Login Response ");
        
        OMMItemEvent ie = (OMMItemEvent) event;
        OMMMsg respMsg = ie.getMsg();

        // The login is unsuccessful, RFA forwards the message from the network
        if (respMsg.isFinal()) {
        	log.info("Login Response message is final.");
        	
        	GenericOMMParser.parse(respMsg);
        	_mainApp.loginFailure();
        	return;
        }

        // The login is successful, RFA forwards the message from the network
        if ((respMsg.getMsgType() == OMMMsg.MsgType.STATUS_RESP) && 
                (respMsg.has(OMMMsg.HAS_STATE)) &&
                (respMsg.getState().getStreamState() == OMMState.Stream.OPEN) &&
                (respMsg.getState().getDataState() == OMMState.Data.OK) ) {
        	
        	log.info("Received Login STATUS OK Response");
            GenericOMMParser.parse(respMsg);
            _mainApp.processLogin();
            QuoteStream.loginSuccess = true;
        } else {// This message is sent by RFA indicating that RFA is processing the login 
        	
        	log.info("Received Login Response - "+ OMMMsg.MsgType.toString(respMsg.getMsgType()));
            GenericOMMParser.parse(respMsg);
            QuoteStream.loginSuccess = false;
        
        }
    }
    
    public Handle getHandle() {
    	return _loginHandle;
    }

}
