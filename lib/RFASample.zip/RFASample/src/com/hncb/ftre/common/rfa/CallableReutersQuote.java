package com.hncb.ftre.common.rfa;

import java.io.DataInputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.prefs.InvalidPreferencesFormatException;
import java.util.prefs.Preferences;

import org.apache.log4j.Logger;

import com.hncb.ftre.common.QuoteStream;
import com.hncb.ftre.common.rfa.client.GenericOMMParser;
import com.hncb.ftre.common.rfa.client.ItemManager;
import com.hncb.ftre.common.rfa.client.LoginClient;
import com.reuters.rfa.common.Context;
import com.reuters.rfa.common.DispatchException;
import com.reuters.rfa.common.EventQueue;
import com.reuters.rfa.common.EventSource;
import com.reuters.rfa.dictionary.DictionaryException;
import com.reuters.rfa.omm.OMMEncoder;
import com.reuters.rfa.omm.OMMPool;
import com.reuters.rfa.session.Session;
import com.reuters.rfa.session.omm.OMMConsumer;

public class CallableReutersQuote implements Callable<Boolean> {
	// init log4j
	private static final Logger log = Logger.getLogger(CallableReutersQuote.class);
	
	// Default RFA Object
	private Session _session;
	private EventQueue _eventQueue;
	private OMMConsumer _ommConsumer;
	private OMMEncoder _encoder;
	private OMMPool _pool;
	
	private LoginClient _loginClient;
	private ItemManager _itemManager;
	
	private String _sessionName;
	private String _serviceName;
	private String _userName;
	private String _fieldDictionaryFilename;
	private String _enumDictionaryFilename;
	private String _feedConfigFilename;
	
	private String _eventQueueName = "defaultQueue";
	private String _ommConsumerName = "defaultConsumer";
	
	public CallableReutersQuote(String sessionName, String serviceName, String userName, String fieldDictionaryFilename, String enumDictionaryFilename, String feedConfigFilename) {
		// read from database
		_sessionName = sessionName;
		_serviceName = serviceName;
		_userName = userName;
		_fieldDictionaryFilename = fieldDictionaryFilename;
		_enumDictionaryFilename = enumDictionaryFilename;
		_feedConfigFilename = feedConfigFilename;

        _itemManager = new ItemManager(this);
	}
	
	public void init() {
		// 1. Initialize context
		log.info("Initialize context");
		
		Context.initialize();
		
		try {
			Preferences.importPreferences(new DataInputStream(new FileInputStream(_feedConfigFilename)));
        } catch (IOException e) {
        	log.error("Read " + _feedConfigFilename + " failed. ", e);
        	cleanup();
            return;
        } catch (InvalidPreferencesFormatException e) {
            log.error("Read " + _feedConfigFilename + " failed. ", e);
            cleanup();
            return;
        } 
		
		// 2. Create an Event Queue
		log.info("Create an Event Queue");
        _eventQueue = EventQueue.create( _eventQueueName );
        
        // 3. log and logLevel used log4j library
        
        // 4. Acquire a Session
        log.info("Acquire a Session");
        createSession();
        
        // 5. Create an OMMConsumer event source
        log.info("Create an OMMConsumer event source");
        createOMMConsumer();
        
        try {
        	GenericOMMParser.initializeDictionary(_fieldDictionaryFilename, _enumDictionaryFilename);
    	} catch (DictionaryException ex) {
    		log.error("ERROR: Unable to initialize dictionaries");
    		System.out.println("ERROR: Unable to initialize dictionaries");
    		log.error(ex.getMessage());
    		System.out.println(ex.getMessage());
    		if(ex.getCause() != null) {
    			System.err.println(": " + ex.getCause().getMessage());
    			log.error(": " + ex.getCause().getMessage());
    		}
    		cleanup();
    		return;
    	}
        
        //Create a OMMPool.
        log.info("Create a OMMPool.");
        _pool = OMMPool.create();
        
        log.info("Create an OMMEncoder");
        //Create an OMMEncoder
        _encoder = _pool.acquireEncoder();
	}
	
	public void login() {
		_loginClient = new LoginClient(this);
		
		_loginClient.sendRequest();
	}

    // This method is called by _loginClient upon receiving successful login response.
    public void processLogin() {
        log.info("Login successful.");
        // The application successfully logged in 
        // Now we can send the item(s) request
        itemRequests();
    }

    // This method is called when the login was not successful
    // The application exits
    public void loginFailure() {
    	log.info("Login has been denied / rejected / closed");
    	log.info("Preparing to clean up and exiting");
    	_loginClient = null;
    	cleanup();
    }
    
    public void itemRequests() {
        _itemManager.sendRequest();
	}
	
	public void createSession() {
		_session = Session.acquire( _sessionName );
        if ( _session == null ) {
        	log.info( "Could not acquire session." );
            Context.uninitialize();
        }
	}
	
	private void createOMMConsumer() {
		_ommConsumer = (OMMConsumer) _session.createEventSource(EventSource.OMM_CONSUMER, _ommConsumerName, true);
	}
	
	public void addItem(Set<String> addSet) {
		
		try {
			for(String itemName : addSet) {
				if(!QuoteStream.identifierSet.contains(itemName)) {
					_itemManager.registerItem(itemName);
					QuoteStream.identifierSet.add(itemName);
				}
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void removeItem(Set<String> removeSet) {
		
		try {
			for(String itemName : removeSet) {
				if(QuoteStream.identifierSet.contains(itemName)) {
					_itemManager.removeItem(itemName);
					QuoteStream.identifierSet.remove(itemName);
				}
			}
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	public void cleanup() {
		log.info(Context.string());

        _eventQueue.deactivate();

        if (_itemManager != null) _itemManager.closeRequest();

    	if (_loginClient != null) _loginClient.closeRequest();
    	
    	_eventQueue.destroy();
    	
    	if (_ommConsumer != null) _ommConsumer.destroy();

        _session.release();

        Context.uninitialize();
        
        QuoteStream.loginSuccess = false;

        log.info(getClass().toString() + " exiting");
    }
	
	@Override
	public Boolean call() throws Exception {
		// TODO Auto-generated method stub
		init();
		login();
		
		while(true) {
			try {
				
				if(!QuoteStream.addItemSet.isEmpty()) {
					Set<String> addSet = new LinkedHashSet<String>();
					addSet.addAll(QuoteStream.addItemSet);
					QuoteStream.addItemSet.clear();
					addItem(addSet);
				}
				
				if(!QuoteStream.removeItemSet.isEmpty()) {
					Set<String> removeSet = new LinkedHashSet<String>();
					removeSet.addAll(QuoteStream.removeItemSet);
					QuoteStream.removeItemSet.clear();
					removeItem(removeSet);
				}
				
				if(QuoteStream.cancel) {
					cleanup();
					QuoteStream.cancel = false;
				}
				
	            _eventQueue.dispatch( 1000 );
	        } catch (DispatchException de ) {
	        	log.error("EventQueue has been deactivated", de);
	            return false;
	        }
		}
	}

	public Session get_session() {
		return _session;
	}

	public void set_session(Session _session) {
		this._session = _session;
	}

	public EventQueue get_eventQueue() {
		return _eventQueue;
	}

	public void set_eventQueue(EventQueue _eventQueue) {
		this._eventQueue = _eventQueue;
	}

	public OMMConsumer get_ommConsumer() {
		return _ommConsumer;
	}

	public void set_ommConsumer(OMMConsumer _ommConsumer) {
		this._ommConsumer = _ommConsumer;
	}

	public OMMEncoder get_encoder() {
		return _encoder;
	}

	public void set_encoder(OMMEncoder _encoder) {
		this._encoder = _encoder;
	}

	public OMMPool get_pool() {
		return _pool;
	}

	public void set_pool(OMMPool _pool) {
		this._pool = _pool;
	}

	public String get_sessionName() {
		return _sessionName;
	}

	public void set_sessionName(String _sessionName) {
		this._sessionName = _sessionName;
	}

	public String get_serviceName() {
		return _serviceName;
	}

	public void set_serviceName(String _serviceName) {
		this._serviceName = _serviceName;
	}

	public String get_userName() {
		return _userName;
	}

	public void set_userName(String _userName) {
		this._userName = _userName;
	}

	public String get_fieldDictionaryFilename() {
		return _fieldDictionaryFilename;
	}

	public void set_fieldDictionaryFilename(String _fieldDictionaryFilename) {
		this._fieldDictionaryFilename = _fieldDictionaryFilename;
	}

	public String get_enumDictionaryFilename() {
		return _enumDictionaryFilename;
	}

	public void set_enumDictionaryFilename(String _enumDictionaryFilename) {
		this._enumDictionaryFilename = _enumDictionaryFilename;
	}

	public String get_feedConfigFilename() {
		return _feedConfigFilename;
	}

	public void set_feedConfigFilename(String _feedConfigFilename) {
		this._feedConfigFilename = _feedConfigFilename;
	}

	public String get_eventQueueName() {
		return _eventQueueName;
	}

	public void set_eventQueueName(String _eventQueueName) {
		this._eventQueueName = _eventQueueName;
	}

	public String get_ommConsumerName() {
		return _ommConsumerName;
	}

	public void set_ommConsumerName(String _ommConsumerName) {
		this._ommConsumerName = _ommConsumerName;
	}

	public LoginClient get_loginClient() {
		return _loginClient;
	}

	public void set_loginClient(LoginClient _loginClient) {
		this._loginClient = _loginClient;
	}
}
