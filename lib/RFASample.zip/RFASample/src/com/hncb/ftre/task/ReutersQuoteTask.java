package com.hncb.ftre.task;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.FutureTask;

import com.hncb.ftre.common.QuoteStream;
import com.hncb.ftre.common.rfa.CallableReutersQuote;

public class ReutersQuoteTask {
	
	public static ExecutorService executor = Executors.newFixedThreadPool(1);
	
	public static FutureTask<Boolean> reutersQuote;
	
	public static void setQuoteTask(CallableReutersQuote quote) {
		reutersQuote = new FutureTask<Boolean>(quote);
	}
	
	public static boolean stop() {

		try {
			if(reutersQuote != null) {
				QuoteStream.cancel = true;
				reutersQuote.cancel(true);
				executor.shutdown();
				
				QuoteStream.clearAll();
			} else {
				return false;
			}
		} catch(Exception e) {
			e.printStackTrace();
			return false;
		}
		
		return true;
	}
	
	public static boolean start() {
		try {
			
			/*PropUtil propUtil = new PropUtil();
			
			String env = propUtil.getConfigProp("env");
			
			String _sessionName = propUtil.getConfigProp(env+".rmds.session.name");
			String _serviceName = propUtil.getConfigProp(env+".rmds.service.name");
			String _userName = propUtil.getConfigProp(env+".rmds.username");
			String _fieldDictionaryFilename = propUtil.getConfigProp(env+".rmds.path.FieldDictionary");
			String _enumDictionaryFilename = propUtil.getConfigProp(env+".rmds.path.EnumDictionary");
			String _feedConfigFilename = propUtil.getConfigProp(env+".rmds.path.FeedConfig");*/
			
			String _sessionName = "myNS::RSSLSession";
			String _serviceName = "IDN_RDF";
			String _userName = "Mike";
			String _fieldDictionaryFilename = "C:/rfa/RDMFieldDictionary";
			String _enumDictionaryFilename = "C:/rfa/enumtype.def";
			String _feedConfigFilename = "C:/rfa/FeedConfig.xml";
			
			CallableReutersQuote quote = new CallableReutersQuote(_sessionName, _serviceName, _userName, _fieldDictionaryFilename, _enumDictionaryFilename, _feedConfigFilename);
			
			executor = Executors.newFixedThreadPool(1);
			setQuoteTask(quote);
			
			if(reutersQuote != null) {
				executor.execute(reutersQuote);
			} else {
				return false;
			}
		} catch(Exception e) {
			e.printStackTrace();
			return false;
		}
		return true;
	}
	
	public static boolean isRunning() {
		
		if(!executor.isShutdown() && reutersQuote != null && !reutersQuote.isDone())  {
			return true;
		} 
		
		return false;
	}
	
	public static void main(String[] args) {
		String[] rics = {".SPX", ".STOXX50E", "US10YT=RR", "US30YT=RR", "=USD", "CNY=", ".HSI", ".TWII", "US1YT=RR"};
		for(int i = 0; i < rics.length; i++) {
			QuoteStream.identifierSet.add(rics[i]);
		}
		// "RIC", "Last Price", "Percent Change", "Net Change", "Close Yield", "Mid Yield", "Exchange Code"
		
		// .SPX
		
		QuoteStream.fieldSet.add("TRDPRC_1"); // Last Price
		QuoteStream.fieldSet.add("PCTCHNG"); // Percent Change
		QuoteStream.fieldSet.add("NETCHNG_1"); // Net Change
		QuoteStream.fieldSet.add("RDN_EXCHID"); // Exchange Code
		QuoteStream.fieldSet.add("YIELD");
		QuoteStream.fieldSet.add("SNP_CLSYLD");

		try {
			ReutersQuoteTask.start();
			
			new Thread().sleep(30 * 1000);
			QuoteStream.removeItemSet.add("=USD");
			new Thread().sleep(30 * 1000);
			QuoteStream.addItemSet.add("JPY=");
			QuoteStream.addItemSet.add("TWD=");
			new Thread().sleep(2 * 60 * 1000);
			QuoteStream.removeItemSet.add("JPY=");
			new Thread().sleep(2 * 60 * 1000);
			
			ReutersQuoteTask.stop();
			
		} catch(Exception e) {
			
		} finally {
			executor.shutdown();
		}
		
	}
}
